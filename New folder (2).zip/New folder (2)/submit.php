<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    // Format the data
    $data = "Name: $name\nEmail: $email\nMessage: $message\n\n";

    // Open the text file in append mode
    $file = fopen("data.txt", "a");

    // Write the data to the file
    fwrite($file, $data);

    // Close the file
    fclose($file);

    // Redirect back to the form page
    header("Location: index.html");
    exit();
}
?>
